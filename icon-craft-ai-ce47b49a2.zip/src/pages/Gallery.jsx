
import React, { useState, useEffect } from "react";
import { GeneratedIcon } from "@/api/entities";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Download, Heart, Search, Filter, Trash2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function GalleryPage() {
  const [icons, setIcons] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStyle, setFilterStyle] = useState("all");
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadIcons();
  }, []);

  const loadIcons = async () => {
    setIsLoading(true);
    try {
      const data = await GeneratedIcon.list("-created_date");
      setIcons(data);
    } catch (error) {
      console.error("Failed to load icons:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const filteredIcons = icons.filter(icon => {
    const matchesSearch = icon.concept.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStyle = filterStyle === "all" || icon.style === filterStyle;
    return matchesSearch && matchesStyle;
  });

  const downloadIcon = (icon) => {
    const link = document.createElement('a');
    link.href = icon.image_url;
    link.download = `icon-${icon.concept.toLowerCase().replace(/\s+/g, '-')}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const toggleFavorite = async (icon) => {
    try {
      await GeneratedIcon.update(icon.id, { is_favorite: !icon.is_favorite });
      loadIcons();
    } catch (error) {
      console.error("Failed to update favorite:", error);
    }
  };

  const deleteIcon = async (iconId) => {
    try {
      await GeneratedIcon.delete(iconId);
      loadIcons();
    } catch (error) {
      console.error("Failed to delete icon:", error);
    }
  };

  return (
    <div className="p-4 sm:p-6 md:p-8">
      <div className="max-w-7xl mx-auto">
        <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-10"
        >
          <p className="text-lg text-slate-600 max-w-3xl mx-auto">
            Browse, manage, and download your collection of AI-generated icons.
          </p>
        </motion.div>

        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
            <Input
              placeholder="Search your icons..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-white/80 backdrop-blur-sm border-slate-200"
            />
          </div>
          <Select value={filterStyle} onValueChange={setFilterStyle}>
            <SelectTrigger className="w-full md:w-48 bg-white/80 backdrop-blur-sm border-slate-200">
              <Filter className="w-4 h-4 mr-2" />
              <SelectValue placeholder="Filter by style" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Styles</SelectItem>
              <SelectItem value="flat_minimalist">Flat Minimalist</SelectItem>
              <SelectItem value="line_art">Line Art</SelectItem>
              <SelectItem value="airbnb_style">Airbnb Style</SelectItem>
              <SelectItem value="doodle_style">Doodle Style</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <AnimatePresence mode="wait">
          {isLoading ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
            >
              {Array(8).fill(0).map((_, i) => (
                <div key={i} className="animate-pulse">
                  <Card className="bg-white/80 backdrop-blur-sm">
                    <CardContent className="p-6">
                      <div className="aspect-square bg-slate-200 rounded-lg mb-4"></div>
                      <div className="h-4 bg-slate-200 rounded mb-2"></div>
                      <div className="h-3 bg-slate-200 rounded w-2/3"></div>
                    </CardContent>
                  </Card>
                </div>
              ))}
            </motion.div>
          ) : filteredIcons.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-16"
            >
              <div className="w-32 h-32 mx-auto mb-6 bg-gradient-to-br from-slate-100 to-slate-200 rounded-full flex items-center justify-center">
                <Search className="w-16 h-16 text-slate-400" />
              </div>
              <h3 className="text-xl font-semibold text-slate-600 mb-2">
                {searchTerm || filterStyle !== "all" ? "No icons found" : "No icons yet"}
              </h3>
              <p className="text-slate-500">
                {searchTerm || filterStyle !== "all" 
                  ? "Try adjusting your search or filter" 
                  : "Generate your first icon to get started"}
              </p>
            </motion.div>
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
            >
              {filteredIcons.map((icon, index) => (
                <motion.div
                  key={icon.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="group"
                >
                  <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.02] overflow-hidden">
                    <CardContent className="p-6">
                      <div className="relative mb-4">
                        <div className="aspect-square bg-gradient-to-br from-slate-100 to-slate-200 rounded-lg p-4 shadow-inner">
                          <img
                            src={icon.image_url}
                            alt={icon.concept}
                            className="w-full h-full object-contain"
                          />
                        </div>
                        <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                          <div className="flex gap-1">
                            <Button
                              size="icon"
                              variant="secondary"
                              className="h-8 w-8 bg-white/80 hover:bg-white shadow-lg"
                              onClick={() => toggleFavorite(icon)}
                            >
                              <Heart className={`w-4 h-4 ${icon.is_favorite ? 'fill-red-500 text-red-500' : 'text-slate-500'}`} />
                            </Button>
                            <Button
                              size="icon"
                              variant="secondary"
                              className="h-8 w-8 bg-white/80 hover:bg-white shadow-lg"
                              onClick={() => deleteIcon(icon.id)}
                            >
                              <Trash2 className="w-4 h-4 text-red-500" />
                            </Button>
                          </div>
                        </div>
                      </div>
                      
                      <div className="space-y-3">
                        <div>
                          <h3 className="font-semibold text-slate-900 truncate">{icon.concept}</h3>
                          <Badge 
                            variant="secondary" 
                            className="text-xs mt-1"
                          >
                            {icon.style.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                          </Badge>
                        </div>
                        
                        <Button
                          size="sm"
                          onClick={() => downloadIcon(icon)}
                          className="btn-gradient w-full bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600 shadow-lg shadow-indigo-500/25"
                        >
                          <Download className="w-4 h-4 mr-2" />
                          Download
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
