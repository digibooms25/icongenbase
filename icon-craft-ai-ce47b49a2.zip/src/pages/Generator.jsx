
import React, { useState, useEffect } from "react";
import { GeneratedIcon } from "@/api/entities";
import { User } from "@/api/entities"; 
import { generateWithOpenAI } from "@/api/functions";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Sparkles, Zap, AlertCircle, Coins } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

import ConceptInput from "../components/generator/ConceptInput";
import StyleSelector from "../components/generator/StyleSelector";
import GenerationResult from "../components/generator/GenerationResult";

const MASTER_PROMPTS = {
  flat_minimalist: `{
    "icon_style": {
      "perspective": "flat, top-down",
      "geometry": {
        "proportions": "1:1 ratio canvas, with objects centered and well-spaced",
        "element_arrangement": "single dominant object or balanced pair, no overlapping"
      },
      "composition": {
        "element_count": "1–2 primary elements only",
        "spatial_depth": "none—pure flat design without shadow or elevation",
        "scale_consistency": "precise, consistent sizing across the set",
        "scene_density": "minimal, emphasizing negative space"
      },
      "lighting": {
        "type": "none",
        "shadow": "none",
        "highlighting": "none"
      },
      "textures": {
        "material_finish": "solid color fills",
        "surface_treatment": "no texture—pure flat vectors",
        "texture_realism": "none—fully stylized abstraction"
      },
      "render_quality": {
        "resolution": "vector-style sharpness (SVG-like)",
        "edge_definition": "crisp, no gradients or depth; clear shape separation",
        "visual_clarity": "high contrast between icon and background"
      },
      "color_palette": {
        "tone": "bold yet clean colors",
        "range": "limited palette (2–3 harmonious tones per icon)",
        "usage": "distinct color fills with no outlines"
      },
      "stylistic_tone": "modern, tech-friendly, professional yet approachable"
    }
  }`,
  
  line_art: `{
    "icon_style": {
      "perspective": "flat, top-down",
      "geometry": {
        "proportions": "1:1 ratio canvas, centered objects",
        "element_arrangement": "single or paired outlined elements"
      },
      "composition": {
        "element_count": "1–2 primary outlined objects",
        "spatial_depth": "none—pure 2D lines",
        "scale_consistency": "consistent line thickness",
        "scene_density": "ultra-minimal"
      },
      "lighting": {
        "type": "none",
        "shadow": "none",
        "highlighting": "none"
      },
      "render_quality": {
        "resolution": "high vector clarity",
        "edge_definition": "consistent line weight",
        "visual_clarity": "maximum readability"
      },
      "color_palette": {
        "tone": "monochrome or minimal accent",
        "range": "black, white, or single accent",
        "usage": "lines are primary; fill optional"
      },
      "stylistic_tone": "minimalist, timeless"
    }
  }`,
  
  airbnb_style: `{
  "icon_style": {
    "perspective": "isometric",
    "geometry": {
      "proportions": "1:1 ratio canvas, with objects fitting comfortably within margins",
      "element_arrangement": "central dominant object, with supporting elements symmetrically or diagonally placed"
    },
    "composition": {
      "element_count": "2–4 main objects",
      "spatial_depth": "layered to create sense of dimension and slight elevation",
      "scale_consistency": "uniform object scale across icon set",
      "scene_density": "minimal to moderate, maintaining clarity and visual focus"
    },
    "lighting": {
      "type": "soft ambient light",
      "light_source": "subtle top-right or front-top direction",
      "shadow": "gentle drop shadows below and behind objects",
      "highlighting": "mild edge illumination to define forms"
    },
    "textures": {
      "material_finish": "semi-matte to satin surfaces",
      "surface_treatment": "smooth with light tactile variation (e.g., wood grain, soft textures)",
      "texture_realism": "stylized naturalism without hyper-realistic noise"
    },
    "render_quality": {
      "resolution": "high-resolution octane 3D rendering",
      "edge_definition": "crisp, no outlines; separation achieved via lighting and depth",
      "visual_clarity": "clean, readable shapes with minimal clutter"
    },
    "color_palette": {
      "tone": "naturalistic with slight saturation boost",
      "range": "harmonious muted tones with gentle contrast",
      "usage": "distinct colors per object to improve identification and readability"
    },
    "stylistic_tone": "premium, friendly, clean with lifestyle or service-oriented appeal",
    "icon_behavior": {
      "branding_alignment": "neutral enough for broad applications",
      "scalability": "legible at small and medium sizes",
      "interchangeability": "part of a cohesive icon system with interchangeable subject matter"
    }
  }
}`,

  doodle_style: `{
  "icon_style": {
    "perspective": "flat, front-facing",
    "geometry": {
      "proportions": "1:1 ratio canvas, objects sized for playful exaggeration",
      "element_arrangement": "single dominant object, optional small decorative accents (swirls, motion lines, spark bursts)"
    },
    "composition": {
      "element_count": "1–2 primary objects with minimal supporting elements",
      "spatial_depth": "none—purely 2D flat design",
      "scale_consistency": "intentionally varied for whimsical effect",
      "scene_density": "ultra-minimal to maintain bold, readable forms"
    },
    "lighting": {
      "type": "none—flat colors only",
      "light_source": "none",
      "shadow": "none",
      "highlighting": "none"
    },
    "textures": {
      "material_finish": "solid fill colors",
      "surface_treatment": "smooth, no texture or gradients",
      "texture_realism": "cartoon simplicity, no realism"
    },
    "render_quality": {
      "resolution": "high vector clarity",
      "edge_definition": "bold black outlines, no soft edges",
      "visual_clarity": "clean, playful shapes with strong contrast"
    },
    "color_palette": {
      "tone": "bright and cheerful with bold accent colors",
      "range": "limited palette with 1–3 main colors plus black outlines",
      "usage": "flat fills with no shading or gradients"
    },
    "stylistic_tone": "fun, playful, cartoonish, hand-drawn look",
    "icon_behavior": {
      "branding_alignment": "suitable for informal, cheerful, or playful brands",
      "scalability": "clear and legible at both small and large sizes",
      "interchangeability": "consistent within a playful icon family"
    }
  }
}`
};

export default function GeneratorPage() {
  const [concept, setConcept] = useState("");
  const [selectedStyle, setSelectedStyle] = useState("flat_minimalist");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedResult, setGeneratedResult] = useState(null);
  const [error, setError] = useState(null);
  const [isRegenerating, setIsRegenerating] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [userCredits, setUserCredits] = useState(10); // Start with an optimistic default

  useEffect(() => {
    // Listen for the initial credit value loaded by the Layout
    const handleInitialCredits = (event) => {
      if (event.detail && typeof event.detail.credits === 'number') {
        setUserCredits(event.detail.credits);
      }
    };
    
    // Listen for general credit updates (e.g., after a generation or purchase)
    const handleCreditsUpdated = (event) => {
      if (event.detail && typeof event.detail.credits === 'number') {
        setUserCredits(event.detail.credits);
      }
    };

    window.addEventListener('initialCreditsLoaded', handleInitialCredits);
    window.addEventListener('creditsUpdated', handleCreditsUpdated); // Keep this listener

    // Cleanup listeners on unmount
    return () => {
      window.removeEventListener('initialCreditsLoaded', handleInitialCredits);
      window.removeEventListener('creditsUpdated', handleCreditsUpdated);
    };
  }, []); // Empty dependency array ensures this runs only once on mount

  const buildPrompt = () => {
    const masterPrompt = MASTER_PROMPTS[selectedStyle];
    return `generate ${concept} icon with this json style ${masterPrompt}`;
  };

  const handleGeneration = async () => {
    if (!concept.trim()) {
      setError("Please enter a concept for your icon.");
      return;
    }

    if (userCredits < 1) {
      setError("You don't have enough credits to generate an image. You need at least 1 credit.");
      return;
    }
    
    // Determine if we are regenerating or starting a new generation
    if (generatedResult) {
      setIsRegenerating(true);
    } else {
      setIsGenerating(true);
    }
    setError(null);

    try {
      const prompt = buildPrompt();
      // FORCE use of OpenAI gpt-image-1 function only
      const { data, error: customError } = await generateWithOpenAI({ prompt });

      if (customError || !data || !data.url) {
        const errorDetails = customError?.details || "The image generator failed. Please check the function logs for more details.";
        throw new Error(`Generation Error: ${errorDetails}`);
      }
      
      const newIcon = {
        concept: concept.trim(),
        style: selectedStyle,
        prompt_used: prompt,
        image_url: data.url
      };
      
      setGeneratedResult(newIcon);
      
      // Update credits from response and dispatch event
      if (data.creditsRemaining !== undefined) {
        setUserCredits(data.creditsRemaining);
        // Dispatch event for layout to update (and for this component's own listener)
        window.dispatchEvent(new CustomEvent('creditsUpdated', { detail: { credits: data.creditsRemaining }}));
      } 

    } catch (err) {
      const errorMessage = err.message || "An unexpected error occurred. Please try again.";
      
      // Handle specific credit errors
      if (errorMessage.includes("Insufficient credits")) {
        setError("You don't have enough credits to generate an image. Please add more credits to continue.");
      } else {
        setError(errorMessage);
      }
      
      console.error("Generation error:", err);
      // If the error happens during regeneration, don't clear the existing result.
      if (!generatedResult) {
        setGeneratedResult(null);
      }
    } finally {
      setIsGenerating(false);
      setIsRegenerating(false);
    }
  };

  const saveIcon = async () => {
    if (!generatedResult) return;
    setIsSaving(true);
    try {
      await GeneratedIcon.create(generatedResult);
      // Optional: Add a success toast/message here
    } catch (err) {
      setError("Failed to save icon. Please try again.");
    } finally {
      setIsSaving(false);
    }
  };

  const startNew = () => {
    setGeneratedResult(null);
    setConcept("");
    setError(null);
  };

  return (
    <div className="w-full min-h-full flex flex-col items-center p-4 sm:p-6 md:p-8">
      {/* Main content area, centered independently */}
      <div className="flex-grow flex flex-col items-center justify-center w-full">
        <AnimatePresence mode="wait">
          {generatedResult ? (
            <motion.div
              key="result"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="w-full max-w-2xl"
            >
              <GenerationResult
                result={generatedResult}
                onRegenerate={() => handleGeneration()}
                onSave={() => saveIcon()}
                isRegenerating={isRegenerating}
                isSaving={isSaving}
                onStartNew={() => startNew()}
              />
            </motion.div>
          ) : (
            <motion.div
              key="form"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="w-full max-w-2xl text-center"
            >
              <h1 className="text-4xl sm:text-5xl font-bold text-slate-800 mt-4">
                Create your perfect icon
              </h1>
              <p className="text-lg text-slate-600 max-w-lg mx-auto mt-4 mb-12">
                Describe your idea, pick a style, and let AI craft your unique icon in seconds.
              </p>

              <div className="space-y-8">
                <ConceptInput
                  concept={concept}
                  onConceptChange={setConcept}
                />
                <StyleSelector
                  selectedStyle={selectedStyle}
                  onStyleChange={setSelectedStyle}
                />

                {error && (
                    <Alert variant="destructive" className="border-red-200 bg-red-50 text-left">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                )}

                <Button
                  onClick={() => handleGeneration()}
                  disabled={isGenerating || !concept.trim() || userCredits < 1}
                  className="btn-gradient w-full h-14 text-lg font-semibold rounded-full bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600 text-white shadow-lg shadow-indigo-500/25 transition-all transform hover:scale-105"
                >
                  {isGenerating ? (
                    <>
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
                        className="w-6 h-6 mr-3"
                      >
                        <Sparkles className="w-6 h-6" />
                      </motion.div>
                      Generating...
                    </>
                  ) : userCredits < 1 ? (
                    <>
                      <Coins className="w-6 h-6 mr-3" />
                      Insufficient Credits
                    </>
                  ) : (
                    <>
                      <Zap className="w-6 h-6 mr-3" />
                      Generate Icon (1 Credit)
                    </>
                  )}
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
