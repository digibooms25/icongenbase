

import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Sparkles, LayoutGrid, User, Menu, Coins } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";

const navigationItems = [
  {
    title: "Icon Generator",
    url: createPageUrl("Generator"),
    icon: Sparkles,
  },
  {
    title: "My Gallery",
    url: createPageUrl("Gallery"),
    icon: LayoutGrid,
  },
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [userCredits, setUserCredits] = React.useState(10); // Optimistic default

  React.useEffect(() => {
    const handleCreditsUpdate = (event) => {
      if (typeof event.detail.credits === 'number') {
        setUserCredits(event.detail.credits);
      }
    };

    window.addEventListener('creditsUpdated', handleCreditsUpdate);
    loadUserCredits(); // Fetch initial credits

    return () => {
      window.removeEventListener('creditsUpdated', handleCreditsUpdate);
    };
  }, []);

  const loadUserCredits = async () => {
    try {
      const { User } = await import("@/api/entities");
      const user = await User.me();
      const newCredits = user.credits ?? 10;
      setUserCredits(newCredits);
      // Dispatch an event so other components know the initial credits have been loaded
      window.dispatchEvent(new CustomEvent('initialCreditsLoaded', { detail: { credits: newCredits } }));
    } catch (error) {
      console.error("Failed to load user credits:", error);
      // Still dispatch with a default value on error to avoid pages getting stuck
      window.dispatchEvent(new CustomEvent('initialCreditsLoaded', { detail: { credits: 10 } }));
    }
  };

  const pageTitles = {
    "Generator": "AI Icon Generator",
    "Gallery": "My Icon Gallery",
  };

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <style>{`
          @import url('https://fonts.googleapis.com/css2?family=Architects+Daughter&display=swap');
          
          :root {
            --background: hsl(0 0% 97.6471%);
            --foreground: hsl(0 0% 22.7451%);
            --card: hsl(0 0% 100%);
            --card-foreground: hsl(0 0% 22.7451%);
            --popover: hsl(0 0% 100%);
            --popover-foreground: hsl(0 0% 22.7451%);
            --primary: hsl(0 0% 37.6471%);
            --primary-foreground: hsl(0 0% 94.1176%);
            --secondary: hsl(0 0% 87.0588%);
            --secondary-foreground: hsl(0 0% 22.7451%);
            --muted: hsl(0 0% 89.0196%);
            --muted-foreground: hsl(0 0% 31.3725%);
            --accent: hsl(47.4419 64.1791% 86.8627%);
            --accent-foreground: hsl(14.2105 25.6757% 29.0196%);
            --destructive: hsl(0 41.4894% 63.1373%);
            --destructive-foreground: hsl(0 0% 100%);
            --border: hsl(0 0.8696% 45.0980%);
            --input: hsl(0 0% 100%);
            --ring: hsl(0 0% 62.7451%);
            --sidebar: hsl(0 0% 94.1176%);
            --sidebar-foreground: hsl(0 0% 22.7451%);
            --sidebar-primary: hsl(0 0% 37.6471%);
            --sidebar-primary-foreground: hsl(0 0% 94.1176%);
            --sidebar-accent: hsl(47.4419 64.1791% 86.8627%);
            --sidebar-accent-foreground: hsl(14.2105 25.6757% 29.0196%);
            --sidebar-border: hsl(0 0% 75.2941%);
            --sidebar-ring: hsl(0 0% 62.7451%);
            --radius: 0.625rem;
          }

          .dark {
            --background: hsl(0 0% 16.8627%);
            --foreground: hsl(0 0% 86.2745%);
            --card: hsl(0 0% 20%);
            --card-foreground: hsl(0 0% 86.2745%);
            --popover: hsl(0 0% 20%);
            --popover-foreground: hsl(0 0% 86.2745%);
            --primary: hsl(0 0% 69.0196%);
            --primary-foreground: hsl(0 0% 16.8627%);
            --secondary: hsl(0 0% 35.2941%);
            --secondary-foreground: hsl(0 0% 75.2941%);
            --muted: hsl(0 0% 27.0588%);
            --muted-foreground: hsl(0 0% 62.7451%);
            --accent: hsl(0 0% 87.8431%);
            --accent-foreground: hsl(0 0% 20%);
            --destructive: hsl(0 35.5932% 76.8627%);
            --destructive-foreground: hsl(0 0% 16.8627%);
            --border: hsl(0 0% 30.9804%);
            --input: hsl(0 0% 20%);
            --ring: hsl(0 0% 75.2941%);
            --sidebar: hsl(0 0% 12.9412%);
            --sidebar-foreground: hsl(0 0% 86.2745%);
            --sidebar-primary: hsl(0 0% 69.0196%);
            --sidebar-primary-foreground: hsl(0 0% 12.9412%);
            --sidebar-accent: hsl(0 0% 87.8431%);
            --sidebar-accent-foreground: hsl(0 0% 20%);
            --sidebar-border: hsl(0 0% 30.9804%);
            --sidebar-ring: hsl(0 0% 75.2941%);
          }

          body {
            font-family: 'Architects Daughter', sans-serif !important;
            letter-spacing: 0.5px;
            background-color: hsl(var(--background));
            color: hsl(var(--foreground));
          }

          * {
            font-family: 'Architects Daughter', sans-serif !important;
            border-color: hsl(var(--border));
          }
          
          /* Sketchy Component Styles */

          .card {
            border-radius: var(--radius) !important;
            border-width: 2px !important;
            box-shadow: 4px 4px 0px 0px hsl(var(--border)) !important;
            transform: rotate(-0.5deg);
          }
          .card:nth-child(even) { transform: rotate(0.4deg); }

          [role="button"], button, .btn {
            border-radius: var(--radius) !important;
            border-width: 2px !important;
            font-weight: 600 !important;
            transform: rotate(-0.2deg);
            transition: all 0.2s ease !important;
            box-shadow: 2px 2px 0px 0px hsl(var(--border)) !important;
          }
          [role="button"]:hover, button:hover, .btn:hover {
            transform: rotate(0.2deg) scale(1.02) !important;
            box-shadow: 4px 4px 0px 0px hsl(var(--border)) !important;
          }
          
          .bg-primary { color: hsl(var(--primary-foreground)) !important; background-color: hsl(var(--primary)) !important; }
          .bg-primary:hover { background-color: hsl(var(--primary) / 0.9) !important; }

          .bg-secondary { color: hsl(var(--secondary-foreground)) !important; background-color: hsl(var(--secondary)) !important; }
          .bg-secondary:hover { background-color: hsl(var(--secondary) / 0.8) !important; }
          
          .btn-gradient {
            color: white !important;
          }

          /* This targets outline buttons */
          .border.bg-transparent:hover {
             background-color: hsl(var(--accent)) !important;
             color: hsl(var(--accent-foreground)) !important;
          }
           .border.bg-background:hover {
             background-color: hsl(var(--accent)) !important;
             color: hsl(var(--accent-foreground)) !important;
          }

          input, textarea, .select-trigger {
            border-radius: var(--radius) !important;
            border-width: 2px !important;
            box-shadow: inset 1px 1px 2px 0px hsl(var(--border) / 0.5) !important;
          }
          input:focus-visible, textarea:focus-visible, .select-trigger[data-state="open"] {
             outline: none !important;
             border-color: hsl(var(--primary)) !important;
             box-shadow: 0 0 0 3px hsl(var(--primary) / 0.2) !important;
          }

          .select-content {
            border-radius: var(--radius) !important;
            border-width: 2px !important;
            box-shadow: 4px 4px 0px 0px hsl(var(--border)) !important;
          }

          .badge {
            border-radius: calc(var(--radius) - 2px) !important;
            border-width: 1.5px !important;
          }

          .alert {
            border-radius: var(--radius) !important;
            border-width: 2px !important;
            box-shadow: 3px 3px 0px 0px hsl(var(--border)) !important;
          }
        `}</style>
        
        <Sidebar className="bg-card text-card-foreground">
          <SidebarHeader className="border-b border-border p-6">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 rounded-xl flex items-center justify-center shadow-lg">
                  <Sparkles className="w-5 h-5 text-white" />
                </div>
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-gradient-to-r from-yellow-400 to-orange-400 rounded-full animate-pulse shadow-sm"></div>
              </div>
              <div>
                <h2 className="font-bold text-foreground text-lg">IconCraft</h2>
                <p className="text-xs text-muted-foreground font-medium">AI Icon Generator</p>
              </div>
            </div>
          </SidebarHeader>
          
          <SidebarContent className="p-4">
            <SidebarGroup>
              <SidebarGroupLabel className="text-xs font-semibold text-muted-foreground uppercase tracking-wider px-3 py-2">
                Tools
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu className="space-y-1">
                  {navigationItems.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton 
                        asChild 
                        className={`group relative overflow-hidden transition-all duration-300 sidebar-menu-button ${
                          location.pathname === item.url 
                            ? 'bg-primary text-primary-foreground shadow-md' 
                            : 'hover:bg-accent hover:text-accent-foreground'
                        }`}
                        style={{borderRadius: 'var(--radius)'}}
                      >
                        <Link to={item.url} className="flex items-center gap-3 px-4 py-3">
                          <item.icon className={`w-5 h-5 transition-transform duration-300 ${
                            location.pathname === item.url ? 'scale-110' : 'group-hover:scale-105'
                          }`} />
                          <span className="font-medium">{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>

            <SidebarGroup className="mt-4">
              <SidebarGroupLabel className="text-xs font-semibold text-muted-foreground uppercase tracking-wider px-3 py-2">
                Quick Stats
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <div className="px-3 py-2 space-y-3">
                  <div className="flex items-center gap-3 text-sm">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                    <span className="text-muted-foreground">AI Ready</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm">
                    <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                    <span className="text-muted-foreground">4 Premium Styles</span>
                  </div>
                </div>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>

          <SidebarFooter className="border-t border-border p-4">
            <div className="flex items-center gap-3 px-2 py-3 rounded-xl bg-accent text-accent-foreground" style={{borderRadius: 'var(--radius)'}}>
              <div className="w-8 h-8 bg-gradient-to-br from-slate-400 to-slate-600 rounded-lg flex items-center justify-center">
                <User className="w-4 h-4 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm truncate">Creative User</p>
                <p className="text-xs truncate">Design amazing icons</p>
              </div>
            </div>
          </SidebarFooter>
        </Sidebar>

        <main className="flex-1 flex flex-col transition-all duration-300">
          <header className="relative sticky top-0 z-10 flex items-center justify-between bg-background/80 backdrop-blur-xl border-b px-4 sm:px-6 py-3">
            <div className="flex items-center gap-2">
              <SidebarTrigger className="-ml-1.5 p-2 rounded-lg hover:bg-accent transition-colors duration-200">
                 <Menu className="w-6 h-6 text-foreground" />
              </SidebarTrigger>
              <h1 className="text-lg md:text-xl font-bold text-foreground hidden md:block">
                {pageTitles[currentPageName] || "IconCraft"}
              </h1>
            </div>

            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 md:hidden">
              <h1 className="text-xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                IconCraft
              </h1>
            </div>

            <div className="flex items-center gap-2">
              <div className="flex items-center gap-2 rounded-full  bg-card px-3 py-1.5 text-sm font-semibold text-foreground" style={{transform: 'rotate(0deg)', boxShadow: '2px 2px 0px 0px hsl(var(--border))'}}>
                <Coins className="h-4 w-4 text-yellow-500" />
                <span className="text-foreground">{userCredits}</span>
              </div>
            </div>
          </header>

          <div className="flex-1 overflow-y-auto bg-background">
            {children}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}

