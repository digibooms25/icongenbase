import { base44 } from './base44Client';


export const GeneratedIcon = base44.entities.GeneratedIcon;



// auth sdk:
export const User = base44.auth;