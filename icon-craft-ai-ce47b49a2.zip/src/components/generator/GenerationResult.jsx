import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, RefreshCw, Heart, PlusCircle, Check } from "lucide-react";

export default function GenerationResult({ 
  result, 
  onRegenerate, 
  onSave,
  onStartNew,
  isRegenerating = false,
  isSaving = false 
}) {
  const [isSaved, setIsSaved] = React.useState(false);

  if (!result) return null;

  const downloadImage = () => {
    const link = document.createElement('a');
    link.href = result.image_url;
    link.download = `icon-${result.concept.toLowerCase().replace(/\s+/g, '-')}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleSave = async () => {
    if (isSaved) return; // Prevent saving if already saved
    await onSave();
    setIsSaved(true);
  };

  // Reset saved state when result changes (new generation)
  React.useEffect(() => {
    setIsSaved(false);
  }, [result.image_url]); // Reset when image URL changes

  return (
    <div className="space-y-6 text-center">
      <h2 className="text-3xl font-bold text-slate-800">Your Icon is Ready!</h2>
      <Card className="overflow-hidden shadow-2xl bg-white/80 backdrop-blur-xl border-0 rounded-3xl">
        <CardContent className="p-6 sm:p-8">
            <div className="w-full max-w-lg mx-auto aspect-square rounded-2xl bg-gradient-to-br from-slate-100 to-slate-200 p-4 sm:p-6 shadow-inner">
              <img
                src={result.image_url}
                alt={result.concept}
                className="w-full h-full object-contain rounded-xl"
              />
            </div>
            <h3 className="text-2xl font-bold text-slate-900 mt-6">{result.concept}</h3>
        </CardContent>
      </Card>
      
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <Button
          onClick={() => onRegenerate()}
          disabled={isRegenerating}
          variant="outline"
          className="h-12 text-md gap-2"
        >
          <RefreshCw className={`w-4 h-4 ${isRegenerating ? 'animate-spin' : ''}`} />
          {isRegenerating ? 'Trying again...' : 'Regenerate'}
        </Button>
        <Button
          onClick={downloadImage}
          variant="outline"
          className="h-12 text-md gap-2"
        >
          <Download className="w-4 h-4" />
          Download
        </Button>
        <Button
          variant="outline"
          onClick={handleSave}
          disabled={isSaving || isSaved}
          className="h-12 text-md gap-2"
        >
          {isSaved ? (
            <>
              <Check className="w-4 h-4" />
              Saved
            </>
          ) : (
            <>
              <Heart className="w-4 h-4" />
              {isSaving ? 'Saving...' : 'Save to Gallery'}
            </>
          )}
        </Button>
        <Button
          onClick={() => onStartNew()}
          className="btn-gradient h-12 text-md gap-2 bg-gradient-to-r from-indigo-500 to-purple-500 text-white"
        >
          <PlusCircle className="w-5 h-5" />
          Create New
        </Button>
      </div>
    </div>
  );
}