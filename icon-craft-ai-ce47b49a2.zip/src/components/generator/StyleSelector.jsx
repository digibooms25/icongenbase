import React from "react";

const STYLES = [
  {
    id: "flat_minimalist",
    name: "Flat",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/27be0db50_flat.png",
  },
  {
    id: "line_art",
    name: "Line Art",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/ed4960617_line.png",
  },
  {
    id: "airbnb_style",
    name: "3D",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/146dc36f2_3d.png",
  },
  {
    id: "doodle_style",
    name: "Doodle",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/f31cf5cff_doodle.png",
  },
];

export default function StyleSelector({ selectedStyle, onStyleChange }) {
  return (
    <div className="flex justify-center">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {STYLES.map((style) => (
          <button
            key={style.id}
            onClick={() => onStyleChange(style.id)}
            className={`flex flex-col items-center p-4 rounded-xl transition-all duration-300 hover:scale-105 ${
              selectedStyle === style.id
                ? 'bg-white border-2 border-indigo-500 shadow-lg'
                : 'bg-white border-2 border-gray-200 hover:border-gray-300 shadow-md'
            }`}
          >
            <div className="w-24 h-24 mb-3 flex items-center justify-center bg-white rounded-lg overflow-hidden">
              <img
                src={style.image}
                alt={style.name}
                className="w-20 h-20 object-contain"
              />
            </div>
            <span className={`text-sm font-medium ${
              selectedStyle === style.id ? 'text-indigo-700' : 'text-gray-700'
            }`}>
              {style.name}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}