import React from "react";
import { Input } from "@/components/ui/input";

export default function ConceptInput({ concept, onConceptChange }) {
  return (
    <div className="relative">
      <Input
        placeholder="e.g., A smiling robot waving, a rocket ship in space..."
        value={concept}
        onChange={(e) => onConceptChange(e.target.value)}
        className="w-full h-16 text-center text-xl px-6 rounded-full border-2 border-slate-200 focus:border-indigo-500 focus:ring-indigo-500 transition-all shadow-inner"
        autoFocus
      />
    </div>
  );
}